import 'bootstrap/dist/css/bootstrap.min.css';
import HomePage from './HomePage';

function App() {
  return (
    <div className="App">
      <HomePage />
    </div>
  );
}

export default App;
